import datetime
import json
from itertools import chain

from django.db.models import Max, Sum
# from django.db.models import Count, Max, Sum
# from django.db.models import Count
from django.http import JsonResponse, HttpResponse
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.permissions import IsAuthenticated

# from django.db import connection
# from rest_framework.pagination import PageNumberPagination
# from rest_framework.parsers import JSONParser

from device.api.serializers import DeviceSerializer, DeviceListSerializer
from device.models import Device, DeviceReg, TempDevice


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def deviceList(request):
    if request.method == 'GET':
        devices = Device.objects.raw('SELECT d.id, MAX(d.created_at) AS created_at, d.device_id, SUM(energy_consumption) as energy_consumption, c.value, dr.location, dr.status, dr.today_total, dr.yesterday_total, d.is_powered, d.total_consumption FROM ((temp_device_data AS d INNER JOIN device_connection AS c ON d.is_connected_id = c.id)INNER JOIN device_reg AS dr ON d.device_detail_id = dr.id)GROUP BY d.device_id ORDER BY device_id ASC')
        # devicess = DeviceReg.objects.values('device_id', 'location', 'device__is_connected__device',).annotate(created_at=Max('device__timestamp'), energy_consumption=Sum('device__energy_consumption'))
        # sdevice = Device.objects.values('device_id', 'device_detail__location', 'energy_consumption').annotate(Count('device_id'), timestamp=Max('timestamp'), d=Count('device_detail'))
        # print(devicess)
        # print(len(sdevice))
        # sdevices = DeviceListSerializer(devicess, many=True)
        # print(sdevices.data)
        serializer = DeviceListSerializer(devices, many=True)
        print(serializer.data)
        return JsonResponse(serializer.data, safe=False)
    else:
        return HttpResponse(status=404)

    # elif request.method == 'POST':
    #     data = JSONParser().parse(request)
    #     serializer = DeviceSerializer(data=data)
    #     if serializer.is_valid():
    #         serializer.save()
    #         return JsonResponse(serializer.data, status=201)
    #     return JsonResponse(serializer.errors, status=400)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def deviceDetail(request, pk):
    if request.method == 'GET':
        date_t = datetime.datetime.today().date()
        try:
            device = TempDevice.objects.filter(device_id=pk).order_by('created_at')
            # print(device) , created_at__gte=date_t
            serializer = DeviceSerializer(device, many=True)
            # print(serializer.data)
            return JsonResponse(serializer.data, status=200, safe=False)
        except Device.DoesNotExist:
            return HttpResponse(status=404)
    else:
        return HttpResponse(status=404)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def all_deviceList(request):
    if request.method == 'GET':
        try:
            # devices = Device.objects.all().order_by('created_at')
            date_t = datetime.datetime.today().date()
            # print(date_t)
            p_devices = Device.objects.all().order_by('created_at')
            print(p_devices)
            print('--------------------')
            n_devices = TempDevice.objects.all().order_by('created_at')
            print(n_devices)
            sdevices = list(chain(p_devices, n_devices))
            # sdevices = Device.objects.filter().order_by('created_at')
            # paginator = PageNumberPagination()created_at__gte=date_t
            # paginator.page_size = 10
            # result_page = paginator.paginate_queryset(devices, request)
            # serializer = DeviceSerializer(devices, many=True)
            serializer2 = DeviceSerializer(sdevices, many=True)
            # print(serializer2.data)
            return JsonResponse(serializer2.data, safe=False)
        except Device.DoesNotExist:
            return HttpResponse(status=404)
    else:
        return HttpResponse(status=404)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def device_list_filter(request):
    data = json.loads(request.body)
    cur_date = datetime.datetime.today().date()
    from_str = data['fromDate'].split('T')
    to_str = data['toDate'].split('T')
    from_date = datetime.datetime.strptime(from_str[0], "%Y-%m-%d").date()
    to_date = datetime.datetime.strptime(to_str[0], "%Y-%m-%d").date()
    # print(cur_date)
    #     # print('from', data['fromDate'])
    #     # print(datetime.datetime.strptime(from_str[0], "%Y-%m-%d").date())
    if from_date == cur_date and to_date == cur_date:
        # print('both current')
        devices = TempDevice.objects.filter(created_at__range=(data['fromDate'], data['toDate'])).order_by('created_at')
    elif from_date != cur_date and to_date == cur_date:
        # print('in prev day and today')
        p_devices = Device.objects.filter(created_at__gte=from_date).order_by('created_at')
        n_devices = TempDevice.objects.filter(created_at__lte=to_date).order_by('created_at')
        devices = list(chain(p_devices, n_devices))
    elif from_date != cur_date and to_date != cur_date:
        # print('both other')
        devices = Device.objects.filter(created_at__range=(data['fromDate'], data['toDate'])).order_by('created_at')
    # devices = Device.objects.filter(created_at__range=(data['fromDate'], data['toDate'])).order_by('created_at')
    # print(devices)
    serializer = DeviceSerializer(devices, many=True)
    return JsonResponse(serializer.data, safe=False)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def device_filter(request, pk):
    data = json.loads(request.body)
    cur_date = datetime.datetime.today().date()
    from_str = data['fromDate'].split('T')
    to_str = data['toDate'].split('T')
    from_date = datetime.datetime.strptime(from_str[0], "%Y-%m-%d").date()
    to_date = datetime.datetime.strptime(to_str[0], "%Y-%m-%d").date()
    # print(cur_date)
    #     # print('from', data['fromDate'])
    #     # print(datetime.datetime.strptime(from_str[0], "%Y-%m-%d").date())
    if from_date == cur_date and to_date == cur_date:
        # print('both current')
        devices = TempDevice.objects.filter(created_at__range=(data['fromDate'], data['toDate']), device_id=pk).order_by('created_at')
    elif from_date != cur_date and to_date == cur_date:
        # print('in prev day and today')
        p_devices = Device.objects.filter(created_at__gte=from_date, device_id=pk).order_by('created_at')
        n_devices = TempDevice.objects.filter(created_at__lte=to_date, device_id=pk).order_by('created_at')
        devices = list(chain(p_devices, n_devices))
    elif from_date != cur_date and to_date != cur_date:
        # print('both other')
        devices = Device.objects.filter(created_at__range=(data['fromDate'], data['toDate']),
                                            device_id=pk).order_by('created_at')
    # devices = Device.objects.filter(created_at__range=(data['fromDate'], data['toDate']), device_id=pk).order_by('created_at')
    # print(devices)
    serializer = DeviceSerializer(devices, many=True)
    # print(serializer.data)
    return JsonResponse(serializer.data, safe=False)
